<?php

namespace Liuggio\ExcelBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class LiuggioExcelBundle extends Bundle
{
}
